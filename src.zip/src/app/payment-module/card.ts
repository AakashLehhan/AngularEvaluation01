export interface Card {
  id: number;
  CardOwnerName: string;
  CardNumber: string;
  ExpirationDate: string;
  SecurityCode: string;
}
